var customEvent = document.createEvent('Event');
customEvent.initEvent('dictcnClose', true, true);

function postDictClose() {
    localStorage['enabled'] = (window.dict_close == 0) ? 'open' : 'close';
    if (window.dict_close == 1) window.dispatchEvent(customEvent)
}

function dictClose() {
    localStorage['enabled'] = 'close';
    if (typeof(window.dict_close) == 'undefined') return;
    if (window.dict_close == 0) window.dictClose()
}

function dictOpen() {
    localStorage['enabled'] = 'open';
    if (typeof(window.dict_close) == 'undefined') {
        {
            var element = document.createElement('script');
            element.setAttribute('src', 'http://chromedict.googlecode.com/svn/trunk/init.js');
            document.body.appendChild(element)
        }
    } else if (window.dict_close == 1) window.dictClose()
}

function checkState() {
    if (localStorage['enabled'] == 'open') dictOpen();
    else dictClose()
}
checkState();